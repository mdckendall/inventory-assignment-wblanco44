import java.util.ArrayList;
import java.util.Scanner;

class Inventory {

  
String name = "" ;
public String serialNumber = "" ;
int value ; 

  public String getserialNumber () {
    return serialNumber; 
    
  }
  
}

class Main {
	public static void main(String[] args) {
  //ArrayList<Object> arrayList = new ArrayList<Inventory> ()  {

    
    Scanner input = new Scanner(System.in);
    int userChoice;
    String item;
   


    
    System.out.println("Enter the name: ");  
    String name = input.nextLine();
    System.out.println("Enter the serial number: ");
    String serialNumber = input.nextLine();
    System.out.println("Enter the value in dollars (whole number): ");
    int value = input.nextInt();

    while (userChoice != 5) {
    System.out.println("Press 1 to add an item.");
    System.out.println("Press 2 to delete an item.");
    System.out.println("Press 3 to update an item.");
    System.out.println("Press 4 to show all the items.");
    System.out.println("press 5 to quit the program.");
    String item = input.nextLine();
      
   int userChoice = Integer.valueOf(scanner.nextLine());
     
    }
   System.out.println("Program has ended.");
   }
    
    
   
  
  
  
  
  
  
  
  
  
  
  
  /*System.out.println("Press 1 to add an item.");
    System.out.println("Press 2 to delete an item.");
    System.out.println("Press 3 to update an item.");
    System.out.println("Press 4 to show all the items.");
    System.out.println("Press 5 to quit the program.");



      
    /*class whileLoop{
   public static void main ( String args[]) {

     int i = 1;
   while (i < 6){
   System.out.println("Enter the name: ");

   i++;

   }
   }
    }
  
/*   System.out.println("Enter the name: ");
    String name = scan.nextline();
    System.out.println("Enter the serial number: ");
  public String getserialNumber = scan.nextline();
    System.out.println("Enter the value in dollars (whole number): ");
    int value = get.nextint() ;
*/
    
  
